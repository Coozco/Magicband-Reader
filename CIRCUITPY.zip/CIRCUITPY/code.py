import random
import time
import board
import digitalio
import audiobusio
from audiocore import WaveFile
import neopixel
from adafruit_led_animation.animation.chase import Chase
from adafruit_led_animation.animation.pulse import Pulse
from adafruit_led_animation.animation.solid import Solid
from adafruit_led_animation.color import GREEN, WHITE

# Setup button switch
button = digitalio.DigitalInOut(board.GP1)
button.switch_to_input(pull=digitalio.Pull.DOWN)

# Setup audio output
audio = audiobusio.I2SOut(bit_clock=board.GP11, word_select=board.GP12, data=board.GP13)

# Setup NeoPixel LEDs
pixels = neopixel.NeoPixel(board.GP0, 38, brightness=1)

# Setup LED animations
chase = Chase(pixels, speed=0.01, color=WHITE, size=4, spacing=34)
pulse = Pulse(pixels, speed=0.01, color=WHITE, period=8)
solid = Solid(pixels, color=GREEN)

# List of audio files
sounds = [
    'chime',
    'excellent',
    'foolish',
    'hello',
    'operational',
    'startours'
]

silence = [
    'silence'
]

# Function to play a WAV file
def play_wav(name):
    print("Playing", name)
    wave_file = open('sounds/' + name + '.wav', 'rb')
    wave = WaveFile(wave_file)
    audio.play(wave)

# Define states
WAITING = 0
PLAYING_AUDIO = 1
SOLID_COLOR = 2

state = WAITING  # Start in the waiting state

while True:
    if state == WAITING:
        print("Waiting for button press to continue!")
        while not button.value:
            pulse.animate()  # Waiting animation

        # Button pressed, play a silent sound
        play_wav(random.choice(silence))
        state = PLAYING_AUDIO  # Move to the next state

    elif state == PLAYING_AUDIO:
        # Run chase animation while audio is playing
        while audio.playing:
            chase.animate()
            time.sleep(0.01)  # Allow animation updates

        print("Audio finished.")
        state = SOLID_COLOR  # Transition to solid color

    elif state == SOLID_COLOR:
        solid.animate()  # Show solid color

        # Play a random sound from the sounds list
        play_wav(random.choice(sounds))

        # Keep solid color while audio plays
        while audio.playing:
            solid.animate()
            time.sleep(0.05)

        # Show solid color for 2 seconds before resetting
        time.sleep(2)

        # Transition back to waiting for button press
        state = WAITING
